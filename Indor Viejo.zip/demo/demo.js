addEventListener('DOMContentLoaded', function () {

	pickmeup('#fecha-init-riego', {
		flat      : true,
		mode      : 'range',
		calendars : 1
	});

//	pickmeup('#fecha-end-riego', {
//		position       : 'up',
//		hide_on_select : true
//	});


});
